console.log("Hallo Welt!");

//For-Schleife
for (let i = 0; i < 5; i++) {}

//While
while (notFinished) {... }

//Kommentar
/*KOMMENTAR*/

//Bedingungen
condintionals(
        if statements):
    if (...) {
        ...
    } else {
        ...
    }

function hallo() {
    console.log("Hallo!");
    console.log("Welt!");
}
hallo();
hallo();

/*So geht es auch

hallo();
hallo();
function hallo(){
    console.log("Hallo");
    console.log("Welt");
}

*/

//Function scope variable -> Javascript ist nicht Typisiert = kann dumme fehler machen
var x = 15;
//Block scope variable
let fruit = 'apple';
//Block scope constant; cannot be reassigned
const isHungry = true;

if (..) {
    let x = 5;
}
//Auf x kann hier nicht zugegriffen werden -> im Block nur

if (...) {
    var x = 5;
}
//Auf x kann zugegriffen werden 
//x ist 5

//Gleichheit
'' == '0' //false
'' == 0 //true
0 == '0' //true
NaN === NaN //false
    [''] == '' //true
false == undefined //false
false == null //false
null == undefined //true

    '' === '0' //false
'' === 0 //false
0 === '0' //false
NaN === NaN //false
    [''] === '' //false
false === undefined //false
false === null //false
null === undefined //false

let x = null; //null
let y; //undefined
let z = undefined; //undefined

//Erstellt eine leere Liste
let list = [];
let groceries = ['milk', 'flour'];
groceries[1] = 'sugar';

//Liste iterieren
let groceries = ['milk', 'sugar'];
for (let i = i < groceries.length; i++) {
    console.log(groceries[i]);
}
//oder
for (let item of groceries) {
    console.log(item);
}

//Maps für Objects
const scores = {};
const prices = {
    //Key:Value Pair
    'bananas': 3,
    'apples': 4,
    'tomatoes': 1
};
console.log(scores['bananas']);

//Iterieren über Maps
const prices = {
    'bananas': 3,
    'apples': 4,
    'tomatoes': 1
};
for (let fruit in prices) {
    console.log(fruit + ' costs ' + scores[fruit]);
}

//-------------Events-------------------------
/*
Das meiste im Browser geschriebene JavaScript ist ereignisgesteuert.
Der Code wird nicht sofort ausgeführt,
sonder erst, nachdem ein Ereignis eingetreten ist.

Jede Funktion, die auf dieses Ereignis wartet, wird nun ausgeführt.
Diese Funktion wird als "Ereignisbehandler"/"Event Handler" bezeichnet.

HTML IST EINE ART BAUMSTRUKTUR MIT KNOTENOBJEKTEN
JS-Code kann Knoten untersuchen , Attribute bearbeiten und Elemente hinzufügen/entfernen.

Über die Funktion querySelector/quereySelectorAll können wir in Javascript auf den entsprechenden DOM-Knoten 
eines HTML-Elements zugreifen.
*/

//Gibt das erste Element zurück
document.querySelector('css selector');
//Gibt alle Elemente zurück
document.querySelectorAll('css selector');

/*
Liefert das DOM-Objekt für das HTML-Element
mit id="button", oder null, wenn keines existiert.
*/
let elemenet = document.querySelector('#button');

/*
Gibt eine Liste von DOM-Objekten zurück, die alle
Elemente mit der Klasse "quote" UND alle
Elemente, die die Klasse "Kommentar" haben.
*/
let elementLIst = document.querySelectorAll('.quote,.comment');

//Event Listener hinzufügen
addEventListener(event name, function name);

//Event Listener entfernen
removeEventListener(event name, function name);

//Event Listener können auch in das HTML eingebettet werden.

function onClick() {
    console.log("Hallo Welt");

} <
button onclick = "onClick()" > Kick mich! < /button>