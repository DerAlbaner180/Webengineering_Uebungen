function printMessage(message, times) {
    for (var i = 0; i < times; i++) {
        console.log(message);
    }

}
printMessage("Hallo Welt", 5);