let board = ['', '', '', '', '', '', '', '', ''];
let currentPlayer = 'X';
let gameOver = false;

function makeMove(index) {
    if (gameOver == false) {
        let feld = event.currentTarget;
        if (!(feld.innerHTML == "X" || feld.innerHTML == "O")) {
            board[index] = currentPlayer;
            if (currentPlayer == "X") {
                currentPlayer = "O";
            } else {
                currentPlayer = "X";
            }
            feld.innerHTML = board[index];
        }

        if ((board[0] == "X" && board[1] == "X" && board[2] == "X") || (board[0] == "O" && board[1] == "O" && board[2] == "O")) {
            document.body.style.animation = "move 3s infinite";
            window.alert("Sie habe gewonnen.");
            gameOver = true;
        }
        if ((board[3] == "X" && board[4] == "X" && board[5] == "X") || (board[3] == "O" && board[4] == "O" && board[5] == "O")) {
            document.body.style.animation = "move 3s infinite";
            window.alert("Sie habe gewonnen.");
            gameOver = true;
        }
        if ((board[8] == "X" && board[6] == "X" && board[7] == "X") || (board[6] == "O" && board[7] == "O" && board[8] == "O")) {
            document.body.style.animation = "move 3s infinite";
            window.alert("Sie habe gewonnen.");
            gameOver = true;
        }


        if ((board[0] == "X" && board[3] == "X" && board[6] == "X") || (board[0] == "O" && board[3] == "O" && board[6] == "O")) {
            document.body.style.animation = "move 3s infinite";
            window.alert("Sie habe gewonnen.");
            gameOver = true;
        }
        if ((board[1] == "X" && board[4] == "X" && board[7] == "X") || (board[1] == "O" && board[4] == "O" && board[7] == "O")) {
            document.body.style.animation = "move 3s infinite";
            window.alert("Sie habe gewonnen.");
            gameOver = true;
        }
        if ((board[2] == "X" && board[5] == "X" && board[8] == "X") || (board[2] == "O" && board[5] == "O" && board[8] == "O")) {
            document.body.style.animation = "move 3s infinite";
            window.alert("Sie habe gewonnen.");
            gameOver = true;
        }


        if ((board[0] == "X" && board[4] == "X" && board[8] == "X") || (board[0] == "O" && board[4] == "O" && board[8] == "O")) {
            document.body.style.animation = "move 3s infinite";
            window.alert("Sie habe gewonnen.");
            gameOver = true;
        }
        if ((board[2] == "X" && board[4] == "X" && board[6] == "X") || (board[2] == "O" && board[4] == "O" && board[6] == "O")) {
            document.body.style.animation = "move 3s infinite";
            window.alert("Sie habe gewonnen.");
            gameOver = true;
        }
    }
}

function resetGame() {
    gameOver = false;
    document.body.style.animation = "";
    board = ['', '', '', '', '', '', '', '', ''];
    let allfeld = document.querySelectorAll(".cell");
    for (let cell of allfeld) {
        cell.innerHTML = "";
    }
}