let currentResult = '';

function appendNumber(number) {
    currentResult += number;
    let input = document.querySelector("input");
    input.value = currentResult;
}

function appendOperator(operator) {
    currentResult += operator;
    let input = document.querySelector("input");
    input.value = currentResult;
}

function calculate() {
    document.querySelector("#result").value = `${eval(currentResult)}`
}

function clearResult() {
    currentResult = "";
    let input = document.querySelector("input");
    input.value = "";
}