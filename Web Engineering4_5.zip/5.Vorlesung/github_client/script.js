let Token;
let input = document.getElementById("password");
let List = document.getElementById("repos-list");
let Message = document.getElementById("message");
let Button = document.getElementById("longus");
Button.addEventListener("click", getRepos);

async function getRepos() {
    Token = input.value;
    const response = await fetch("https://api.github.com/user/repos", {
        headers: {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "Authorization": "Bearer " + Token
        }
    })
    if (response.status !== 200) {
        Message.innerHTML = "Fehler";
    } else {
        const penis = await response.json();
        console.log(penis);
        for (glied of penis) {
            const node = document.createElement("li");
            const textnode = document.createTextNode(glied.name)
            node.appendChild(textnode);
            List.appendChild(node);
        }
    }
    console.log(response);
}