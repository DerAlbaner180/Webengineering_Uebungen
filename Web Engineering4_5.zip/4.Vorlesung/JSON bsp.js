function getAll() {
    alert("Info in Console")
    fetch('https://dummyjson.com/products')
        .then(res => res.json())
        .then(console.log);
}

function getOne() {
    alert("Info in Console")
    fetch('https://dummyjson.com/products/' + document.getElementById("product_id").value)
        .then(res => res.json())
        .then(console.log);
}

function del() {
    fetch('https://dummyjson.com/products/' +
            document.getElementById("product_id").value, {
                method: 'DELETE',
            })
        .then(res => res.json())
        .then(console.log);
}

function add() {
    fetch('https://dummyjson.com/products/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                title: 'BMW Pencil',
                /* other product data */
            })
        })
        .then(res => res.json())
        .then(console.log);
}

function update() {
    /* updating title of product with id 1 */
    fetch('https://dummyjson.com/products/' +
            document.getElementById("product_id").value, {
                method: 'PUT',
                /* or PATCH */
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    title: 'iPhone Galaxy +1'
                })
            })
        .then(res => res.json())
        .then(console.log);
}